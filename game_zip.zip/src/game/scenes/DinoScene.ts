import Phaser from "phaser";

export class DinoScene extends Phaser.Scene {
  private runner!: Phaser.Physics.Arcade.Sprite;
  private ground!: Phaser.Physics.Arcade.StaticGroup;
  private obstacles!: Phaser.Physics.Arcade.Group;
  private score = 0;
  private scoreText!: Phaser.GameObjects.Text;

  constructor() {
    super("DinoScene");
  }

  create() {
    this.cameras.main.setBackgroundColor("#222");

    // Ground (static physics group)
    this.ground = this.physics.add.staticGroup();
    this.ground.create(500, 650, "")
      .setDisplaySize(1000, 100)
      .refreshBody()
      .setTint(0x444444);

    // Runner
    this.runner = this.physics.add.sprite(150, 580, "face");
    this.runner.setDisplaySize(80, 80);
    this.runner.setCollideWorldBounds(true);
    this.runner.setGravityY(1500);

    this.physics.add.collider(this.runner, this.ground);

    // Obstacles
    this.obstacles = this.physics.add.group();

    this.time.addEvent({
      delay: 1800,
      callback: this.spawnObstacle,
      callbackScope: this,
      loop: true,
    });

    // Jump input
    this.input.keyboard?.on("keydown-SPACE", () => {
      const body = this.runner.body as Phaser.Physics.Arcade.Body;

      if (body.blocked.down) {
        this.runner.setVelocityY(-700);
      }
    });

    // Collision detection
    this.physics.add.collider(this.runner, this.obstacles, () => {
      this.scene.restart();
    });

    this.scoreText = this.add.text(20, 20, "Passed: 0", {
      fontSize: "22px",
      color: "#ffffff",
    });
  }

  update() {
    this.obstacles.getChildren().forEach((obs) => {
      const obstacle = obs as Phaser.Physics.Arcade.Sprite;

      if (obstacle.x < -50) {
        obstacle.destroy();
        this.score++;
        this.scoreText.setText(`Passed: ${this.score}`);

        if (this.score >= 3) {
          this.scene.start("FlappyScene");
        }
      }
    });
  }

  spawnObstacle() {
    const obstacle = this.physics.add.sprite(1050, 600, "");
    obstacle.setDisplaySize(40, 80);
    obstacle.setTint(0xff0000);
    obstacle.setVelocityX(-450);
    obstacle.setImmovable(true);
    obstacle.body.allowGravity = false;

    this.obstacles.add(obstacle);
  }
}
