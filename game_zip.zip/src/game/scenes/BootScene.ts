import Phaser from "phaser";

export class BootScene extends Phaser.Scene {
    constructor() {
        super("BootScene");
    }

    preload() {
        this.load.image("face", "src/assets/face.png");
    }

    create() {
        this.scene.start("SnakeScene");
    }
}
