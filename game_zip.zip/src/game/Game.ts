import Phaser from "phaser";
import { BootScene } from "./scenes/BootScene";
import { SnakeScene } from "./scenes/SnakeScene";
import { DinoScene } from "./scenes/DinoScene";

export const gameConfig: Phaser.Types.Core.GameConfig = {
    type: Phaser.AUTO,
    width: 1000,
    height: 700,
    backgroundColor: "#000000",
    parent: "game",
    physics: {
        default: "arcade",
        arcade: {
            debug: false,
        },
    },
    scene: [BootScene, SnakeScene, DinoScene],
};

export default new Phaser.Game(gameConfig);
